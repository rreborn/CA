<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class publik extends CI_Controller {
	public function index() {
		/*
		$options = ['salt' => 'jon123456789@gmail.com'];
		echo password_hash('ramen goreng', PASSWORD_BCRYPT, $options);
		*/

		if($this->session->userdata('hak_akses') == null) {
			$this->load->view('home');
		}
		else if($this->session->userdata('hak_akses') == 2){ //publik
			redirect(base_url() . 'publik/member');
		}
		else if ($this->session->userdata('hak_akses') == 1) { //pihak CA
			redirect(base_url(). 'ca/index');
		}
	}

	public function masuk() {
		$this->load->view('login');
	}

	public function submit_masuk() {
		$surel = $this->input->post('email');
		$pass = $this->input->post('password');

		echo $surel;
		echo $pass;
		print_r($_POST);

		if($surel && $pass){
			$this->load->model('akun');
			$akun = $this->akun->autentikasi($surel,$pass);
			if($akun != false){
				print_r ($akun);
				echo "SUCCESS ALKSJDK";
				$userdata = array('id' => $akun->id_akun, 'nama' => $akun->nama, 'hak_akses' => $akun->hak_akses);
				$this->session->set_userdata($userdata);
				$this->index();
			}
			else{
				$this->masuk();
			}
		}
		else{
			$this->masuk();
		}
	}

	public function keluar(){
		$this->session->sess_destroy();
		$this->masuk();
	}

	public function member(){
		$nama = $this->session->userdata('nama');
		$data = ['nama' => $nama];
		$this->load->view('member', $data);
	}
}
?>
