<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class User_request extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		function submit_request() {

			$this->session->set_userdata('id', 1);
			$this->session->set_userdata('hak_akses', 2);
			$this->load->model('request');
			if ($this->session->userdata('hak_akses') != 2) {
				redirect('/publik/member');
				return;
			}

			$this->load->model('request');
			$new_id = $this->request->max_id();
			$userid = $this->session->userdata('id');
			if (!is_dir('./requests/' . $userid)) {
				echo "Creating ./requests/" . $userid;
				mkdir('./requests/' . $userid);
			}
			print_r($_FILES);
			$config['upload_path'] = './requests/' . $userid . '/';
			$config['allowed_types'] = '*';
			$config['file_name'] = $new_id;
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('csr')) {
				echo $this->upload->display_errors();
				return;
			}

			$this->request->insert($userid, './requests/' . $userid .	 '/' . $new_id);
			redirect('/user_request/');
		}
	}

?>
