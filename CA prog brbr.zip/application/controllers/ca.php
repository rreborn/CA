<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class CA extends CI_Controller {

  public function index() {
    if ($this->session->userdata('hak_akses') != 1) {
      redirect('/public/index');
			return;
		}
    $data = ['nama' => $this->session->userdata('nama')];
    $this->load->view('ca_home', $data);
	}

  public function daftar_request() {
    if ($this->session->userdata('hak_akses') != 1) {
      redirect('/public/index');
			return;
		}
    $this->load->model('request');
    $requests = $this->request->get_request_plus_email();
    $data = ['requests' => $requests];
    $this->load->view('daftar_request_ca', $data);
    
  }

  public function daftar_certificate() {
    if ($this->session->userdata('hak_akses') != 1) {
      redirect('/public/index');
      return;
    }
    $this->load->model('certificate');
    $certificates = $this->certificate->get_all_certificate();
    $data = [
      'certificates' => $certificates
    ];
    $this->load->view('semua_sertifikat', $data);

  }

}
?>
