<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Request extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function insert($userid, $common_name, $csr_file){
			$new_req = [
					'common_name' => $common_name,
					'id_akun' => $userid,
					'tanggal' => (new DateTime())->format("Y-m-d H:i:s"),
					'csr_file' => $csr_file
			];

			$this->db->insert('request', $new_req);
		}

		public function max_id() {
			$this->db->select_max('id_csr');
			$query = $this->db->get('request');
			if ($query->num_rows > 0) {
				return $query->row()->id_csr + 1;
			}
			else return 1;
		}

		public function get_request_plus_email() {
			$this->db->select('*');
			$this->db->from('request');
			$this->db->join('akun', 'akun.id_akun = request.id_akun');
			$query = $this->db->get();
			return $query->result();
		}

		public function get_user_request($id) {
			$this->db->where('id_akun', $id);
			$query = $this->db->get('request');
			return $query->result();
		}

		public function get_request_by_id($id) {
			$this->db_>where('id_csr', $id);
			$query = $this->db->get('request');
			return $query->row(); //row isinya cuma 1 entri
		}


	}

?>
