<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Akun extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function autentikasi($email,$pass){
			$this->db->select('id_akun, nama, hak_akses');
			$this->db->from('akun');
			$this->db->where('email', $email);
			$options = ['salt' => $email];
			$this->db->where('password', password_hash($pass, PASSWORD_BCRYPT, $options));
			$query = $this->db->get();
			if ($query->num_rows() > 0) {
				return $query->row();
			}
			else {
				return false;
			}
		}

		public function register($email, $nama, $password, $hak_akses) {
			$options = ['salt' => $email];
			$new_acc = [
				'email' => $email,
				'nama' => $nama,
				'password' => password_hash($password, PASSWORD_BCRYPT, $options),
				'hak_akses' => $hak_akses
			];
			$this->db->insert('akun', $new_acc);
		}

	}

?>
