<!doctype html>
<html>
  <head>
    <title>MyCA</title>
  </head>
  <style>
    body {
      font-family: 'sans serif';
      padding: 0;
      margin: 0;
    }
    .mid {
      text-align: center;
    }

    .navbar a {
      color: black;
    }

    .navbar {
      height: 50px;
      background: black;
    }

    .navbar ul {
      margin: 0;
      padding: 0;
      height: 100%;
    }

    .navbar li {
      color: white;
      font-weight: bold;
      line-height: 50px;
      list-style: none;
      display: inline-block;
      padding-left: 10px;
      padding-right: 20px;
      box-sizing: border-box;
      border-right: solid black 1px;
      background: #666666;
    }

    #button {
      font-size: 1.2em;
      padding: 12px 24px;
      color: white;
      border: 1px solid;
      border-radius: 4px;
      background-color: #5cb85c;
      border-color: #4cae4c;
      cursor: pointer;
      text-decoration: none;
    }

    #logo {
      vertical-align: middle;
      height: 30px;
    }

    .input {
      margin: auto;
      padding: 7px;
      display: block;
      width: 300px;
    }

    .button {
      display: block;
      margin: auto;
      font-size: 1em;
      padding: 8px 12px;
      color: white;
      border: 1px solid;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
    }

    .primary-blue {
      background-color: #217dbb;
      border-color: #2077b2;
    }

    .primary-green {
      background-color: #4cae4c;
      border-color: #4cae4c;
    }

  </style>
  <body>
    <div class="navbar">
      <ul class="navbar-item">
        <li style="background: white; border-bottom: solid #AAAAAA 1px; border-right: none; height: 49px;"><img id="logo" src="/assets/image/Logo.png"></li>
      </ul>
    </div>
    <h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 3em">Selamat Datang</h1>
    <p class="mid" style="font-size: 1.1em">Silahkan mendaftar terlebih dahulu untuk dapat meminta sertifikat digital</p><br>
    <div class="mid"><a href="daftar.php" id="button">Daftar</a></div><br>
    <p class="mid" style="font-size: 0.8em; color: #555555;">Sudah punya akun? silahkan login:</p>
    <form method="post" action="/publik/submit_masuk">
        <input name="email" class="input" placeholder="Email"><br/>
        <input name="password" type="password" class="input" placeholder="Password"><br/>
        <input type="submit" class="button primary-blue" value="Login" style="margin: auto">
    </form>

  </body>
</html>
