<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class User_request extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		function submit_request() {
			$this->load->model('request');
			if ($this->session->userdata('hak_akses') != 2) {
				redirect('/publik/member');
				return;
			}

			$common_name = openssl_csr_get_subject(file_get_contents($_FILES['csr']['tmp_name']))['CN'];

			$this->load->model('request');
			$new_id = $this->request->max_id();
			$userid = $this->session->userdata('id');
			if (!is_dir('./requests/' . $userid)) {
				echo "Creating ./requests/" . $userid;
				mkdir('./requests/' . $userid);
			}

			$config['upload_path'] = './requests/' . $userid . '/';
			$config['allowed_types'] = '*';
			$config['file_name'] = $new_id;
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('csr')) {
				echo $this->upload->display_errors();
				return;
			}

			$this->request->insert($userid, $common_name, './requests/' . $userid .	 '/' . $new_id . '.csr');
			redirect('/member/daftar_sertifikat');

		}
	}

?>
