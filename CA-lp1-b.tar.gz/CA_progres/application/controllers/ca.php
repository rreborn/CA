<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class CA extends CI_Controller {

  public function index() {
    if ($this->session->userdata('hak_akses') != 1) {
      redirect('/public/index');
			return;
		}
    $data = ['nama' => $this->session->userdata('nama')];
    $this->load->view('ca_home', $data);
	}

  public function daftar_request() {
    if ($this->session->userdata('hak_akses') != 1) {
      redirect('/public/index');
			return;
		}
    $this->load->model('request');
    $requests = $this->request->get_request();
    $data = ['requests' => $requests];
    $this->load->view('daftar_request_ca', $data);
  }

  public function sign($id) {
    $this->load->model('request');
    $this->load->model('certificate');

    $request_row = $this->request->get_request_by_id($id);
    $userid = $request_row->id_akun;
    $csr = file_get_contents('/var/www/CA_progres/' . $request_row->csr_file);
    $common_name = openssl_csr_get_subject($csr)['CN'];
    $valid_from = (new DateTime())->format("Y-m-d H:i:s");
    $valid_until = (new DateTime())->add(new DateInterval('P365D'))->format("Y-m-d H:i:s");
    $this->certificate->insert($userid, $common_name, $valid_from, $valid_until);
    $cert_serial = $this->certificate->max_serial();

    $cacert = file_get_contents('/home/wik/CA/certs/ca.cert.pem');
    $privkey = file_get_contents('/home/wik/CA/private/ca.key.pem');
    $csr = file_get_contents('/var/www/CA_progres/' . $this->request->get_request_by_id($id)->csr_file);
    $config = ['x509_extensions' => 'usr_cert'];
    $signed = openssl_csr_sign($csr, $cacert, $privkey, 365, $config, $cert_serial);
    if (!is_dir('./certs/' . $userid)) {
      mkdir('./certs/' . $userid);
    }
    $cert_file = './certs/' . $userid . '/' . $cert_serial . '.crt.pem';
    openssl_x509_export_to_file($signed, $cert_file);
    $this->certificate->update_cert_filename($cert_serial, $cert_file);

    $this->request->delete($id);

    redirect('/ca/daftar_request');
  }

}
?>
