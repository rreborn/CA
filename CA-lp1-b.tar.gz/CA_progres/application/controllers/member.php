<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Member extends CI_Controller {

  public function index() {
    if ($this->session->userdata('hak_akses') != 2) {
			redirect('/public/index');
			return;
		}
		$nama = $this->session->userdata('nama');
		$data = ['nama' => $nama];
		$this->load->view('member', $data);
	}

	public function form_request() {
    if ($this->session->userdata('hak_akses') != 2) {
      redirect('/public/index');
			return;
		}
		$this->load->view('form_request');
	}

  public function daftar_sertifikat() {
    if ($this->session->userdata('hak_akses') != 2) {
      redirect('/public/index');
			return;
		}
    $this->load->model('request');
    $this->load->model('certificate');
    $requests = $this->request->get_user_request($this->session->userdata('id'));
    $certificates = $this->certificate->get_user_certificate($this->session->userdata('id'));
    $data = [
      'requests' => $requests,
      'certificates' => $certificates
    ];
    $this->load->view('sertifikat_user', $data);
  }

}
?>
