
<!doctype html>
<html>
  <head>
    <title>MyCA - Certificate Signing Request Page</title>
  </head>
  <style>
    body {
      font-family: 'sans serif';
      padding: 0;
      margin: 0;
    }
    .mid {
      text-align: center;
    }

    .navbar a {
      color: black;
    }

    .navbar {
      height: 50px;
      background: black;
    }

    .navbar ul {
      margin: 0;
      padding: 0;
      height: 100%;
    }

    .navbar li {
      color: white;
      font-weight: bold;
      line-height: 50px;
      list-style: none;
      display: inline-block;
      padding-left: 10px;
      padding-right: 20px;
      box-sizing: border-box;
      border-right: solid black 1px;
      background: #666666;
    }

    .button {
      display: block;
      margin: auto;
      font-size: 1em;
      padding: 8px 12px;
      color: white;
      border: 1px solid;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
    }

    .primary-blue {
      background-color: #217dbb;
      border-color: #2077b2;
    }

    .primary-green {
      background-color: #4cae4c;
      border-color: #4cae4c;
    }


    #logo {
      vertical-align: middle;
      height: 30px;
    }

    #table, th, td {
      margin: auto;
      border: solid black 1px;
      border-collapse: collapse;
      padding: 15px;
    }

    td a {
      text-decoration: none;
    }

  </style>
  <body>
    <div class="navbar">
      <ul class="navbar-item">
        <li style="background: white; border-bottom: solid #AAAAAA 1px; border-right: none; height: 49px;"><img id="logo" src="logo.png"></li><a href="/ca/index"><li>Home</li></a>
      </ul>
    </div>
    <h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 2em">Daftar Request</h1>
    <table id="table">
      <thead>
        <tr>
          <th>#</th>
          <th>ID CSR</th>
          <th>Common Name</th>
          <th>Tanggal</th>
          <th>Detail</th>
          <th>Operasi</th>
        </tr>
      </thead>
      <tbody>
        <?php $i=1; foreach($requests as $req) { ?>
          <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $req->id_csr;?></td>
            <td><?php echo $req->common_name;?></td>
            <td><?php echo $req->tanggal;?></td>
            <td>
              <ul>
                <?php $subject = openssl_csr_get_subject('file://' . $req->csr_file); ?>
                <li>Common Name: <?php echo $subject['CN']; ?></li>
                <li>Organization: <?php echo $subject['O']; ?></li>
                <li>Organization Unit: <?php echo $subject['OU']; ?></li>
                <li>City: <?php echo $subject['L']; ?></li>
                <li>Email: <?php echo $subject['emailAddress']; ?></li>
              </ul>
            </td>
            <td>
              <a href="<?php echo base_url() . $req->csr_file; ?>" download><button class="button primary-blue">Download</button></a><br/>
              <button class="button primary-green" onclick="verifySign(<?php echo $req->id_csr;?>)">Sign</button>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
    <script>
      function verifySign(id) {
        res = confirm('Yakin ingin menandatangani CSR ini?');
        if (res) {
          //console.log('<?php echo base_url(); ?>ca/sign/' + id);
          window.location = '<?php echo base_url(); ?>ca/sign/' + id;
        }
      }
    </script>
  </body>
</html>
