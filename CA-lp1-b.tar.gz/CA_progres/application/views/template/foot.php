<p class="footer">Develop by:
		<br/><strong>Wik&nbsp&nbsp 5112100013</strong>
		<br/><strong>Ryan&nbsp&nbsp 5112100079</strong>
		<br/><strong>Bili&nbsp&nbsp 5112100172</strong>
		<br/><strong>Anno&nbsp&nbsp 5112100209</strong>
</p>
</div>

</body>
</html>