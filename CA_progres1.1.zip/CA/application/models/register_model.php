<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Register_model extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function index($data){
			try{
				$cek = array(
					'usn' => $data['usn'],
					'pass' => $data['pass'],
					'name' => $data['fullname'],
					'alamat' => $data['addr'],
					'pekerjaan' => $data['job'],
					'email' => $data['email']	);
				$this->db->insert('anggotacertified',$cek);
				return "Success";
			}
			catch(Exception $e){
				return $e;
			}
		}
	}

?>