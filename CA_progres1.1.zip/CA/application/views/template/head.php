<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php if(isset($title))echo $title ?></title>
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/style.css">
	<script type="text/javascript" src="<?=base_url()?>assets/scripts.js"></script>
</head>
<body>

<?php
	if(isset($flag) && $flag==0 ){
		echo "
			<div id='fail'>The login failed</div>
		";
	}
?>

<div id="container">
	<div id="body">
		<div class="navbar">
		  <ul class="navbar-item">
		    <li style="background: white; border-bottom: solid #AAAAAA 1px; border-right: none; height: 49px;">
		    	<img id='logo' src='<?=base_url()?>/assets/image/logo.png'>
		    </li>
		    <?php 
		    	 if(isset($sign) && $sign==1) echo "<li>Home</li></a><a href='sertifikat_user.php'><li>Sertifikat Anda</li></a>";
		    	?>
		  </ul>
		</div>