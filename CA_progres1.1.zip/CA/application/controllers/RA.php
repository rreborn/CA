<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class RA extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function register(){
			$inp['usn'] = $this->input->post('usn');
			$inp['pass'] = $this->input->post('pass');
			$inp['fullname'] = $this->input->post('fullname');
			$inp['addr'] = $this->input->post('addr');
			$inp['job'] = $this->input->post('job');
			$inp['email'] = $this->input->post('email');
			$this->load->model('register_model');
			$out=$this->register_model->index($inp);
			echo $out;
		}

		public function FormRegister(){
			$data['title'] = 'Register user';
			$this->load->view('template/head',$data);
			$this->load->view('register.php');
			$this->load->view('template/foot');
		}
	}

?>