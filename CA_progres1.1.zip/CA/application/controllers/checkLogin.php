<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class CheckLogin extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function index(){
			$usn = $this->input->post('usn');
			$pass = $this->input->post('pass');
			$this->load->model("anggotaCertified");
			$cek = $this->anggotaCertified->doCheck($usn,$pass);

			$data['flag'] = 0;
			$data['title']='Home user';
			$data['usn'] = $usn;
			$data['sign'] = 1;
			if ($cek==1){
				$data['flag'] = 1;
				$this->load->view('template/head',$data);
				$this->load->view('login_success',$data);
				$this->load->view('template/foot');
			}
			else {
				$this->load->view('template/head',$data);
				$this->load->view('welcome_message');
				$this->load->view('template/foot');
			}
		}
	}

?>