		<h2>Register</h2>
		<form action="<?=base_url()?>RA/register" method="post">
		<table>
			<tr>
				<td>Fullname</td>
				<td><input class="inp" type="text" name="fullname" required/></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input class="inp" type="text" name="pass" required/></td>
			</tr>
			<tr>
			<tr>
				<td>Email</td>
				<td><input class="inp" type="text" name="email" required/></td>
			</tr>
			<tr>
				<td><input  id="sub"  class="primary-blue button"  type="submit" value="Register"/></td>
			</tr>
		</table>
		</form>