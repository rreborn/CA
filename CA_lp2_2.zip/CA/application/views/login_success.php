<h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 3em">Selamat Datang, <?php echo $this->session->userdata('nama'); ?></h1>

<p>If you would like to edit this page you'll find it located at:</p>
<div class="mid"><a href="#" id="button" onclick="change('login')">Buat Sertifikat Baru</a></div><br>
<div id='login'>
	<form action="<?=base_url()?>RA/submitCSR" enctype="multipart/form-data" method="post">
		<input class="inp" type="file" name="csr"/><br/>
		<input  id="sub" class="primary-blue button" type="submit" value="Request"/>
	</form>
</div>
<p class="mid" id="info_buat" style="font-size: 0.8em; color: #555555;">Belum punya file CSR? <a id="click_buat" onclick="show_form()" href="#">buat sekarang</a></p>
    <br/>
    <div id="csr_div">
      <div class="form-row">
        <div class="field-label">Common Name</div><input class="field" id="csr-cn">
      </div>
      <div class="form-row">
        <div class="field-label">Organisasi</div><input class="field" id="csr-o">
      </div>
      <div class="form-row">
        <div class="field-label">Departemen / Unit</div><input class="field" id="csr-ou">
      </div>
      <div class="form-row">
        <div class="field-label">Email</div><input class="field" id="csr-email">
      </div>
      <div class="form-row">
        <div class="field-label">Kota</div><input class="field" id="csr-l">
      </div>
      <div class="form-row">
        <div class="field-label">Provinsi</div><input class="field" id="csr-st">
      </div>
      <button class="button primary-green" onclick="generate_command()">Generate</button>
      <p class="mid hint">Setelah mengisi, silahkan copy command di bawah ini di terminal anda untuk membuat file CSR</p>
      <textarea id="output" cols="60" rows="3" class="mid" readonly>
        Silahkan isi form di atas terlebih dahulu
      </textarea>
    </div>