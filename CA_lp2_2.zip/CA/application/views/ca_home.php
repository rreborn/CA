    <h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 3em">Selamat Datang, <?php echo $this->session->userdata('nama'); ?></h1>
    <div class="mid"><a href="<?=base_url()?>CA/daftar_request" id="button">Daftar Request</a></div><br><br/>
    <div class="mid"><a href="<?=base_url()?>CA/daftar_certificate" id="button">Daftar Certificate</a></div><br>
