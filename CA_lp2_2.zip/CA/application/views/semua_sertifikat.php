<h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 2em">Daftar Sertifikat</h1>
<table id="table">
  <thead>
    <tr>
      <th>#</th>
      <th>Serial</th>
      <th>ID Akun</th>
      <th>Common Name</th>
      <th>Valid Dari</th>
      <th>Valid Hingga</th>
      <th>Cert File</th>
    </tr>
  </thead>
  <tbody>
    <?php $i=0;
    foreach($certificates as $cer) { ?>
      <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo $cer->serial;?></td>
        <td><?php echo $cer->id_akun;?></td>
        <td><?php echo $cer->common_name;?></td>
        <td><?php echo $cer->valid_from;?></td>
        <td><?php echo $cer->valid_until;?></td>
        <td><a href="<?php echo $cer->cert_file;?>"><button class="button primary-blue">Download</button></a></td>
      </tr>
    <?php } ?>
  </tbody>
</table>