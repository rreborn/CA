<h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 3em">Selamat Datang</h1>
<p class="mid" style="font-size: 1.1em">Silahkan buat akun terlebih dahulu untuk dapat meminta sertifikat digital</p><br>
<div class="mid"><a href="<?=base_url()?>RA/FormRegister" id="button">Daftar</a></div><br>
<p class="mid" style="font-size: 0.8em; color: #555555;">Sudah punya akun? silahkan <a href="#" onclick="change('login')">login</a></p>


<div id='login'>
	<h2>Login</h2>
		<form action="<?=base_url()?>checkLogin" method="post">
			<table>
				<tr>
					<td>Email</td>
					<td><input class="inp" type="text" name="email" required Placeholder='username'/></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input class="inp" type="password" name="pass" required Placeholder='password'/></td>
				</tr>
				<tr>
					<td><input  id="sub" class="primary-blue button" type="submit" value="login"/></td>
				</tr>
			</table>
		</form>

</div>