<p class="footer">Developed by:
		<strong>5112100013 -</strong>
		<strong> 5112100079 -</strong>
		<strong> 5112100172 -</strong>
		<strong> 5112100209</strong>
</p>

</body>
</html>