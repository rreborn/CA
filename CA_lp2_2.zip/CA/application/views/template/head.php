<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>
		<?php echo $this->session->userdata('title'); ?>
	</title>
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/style.css">
	<script type="text/javascript" src="<?=base_url()?>assets/scripts.js"></script>
</head>
<body>

<?php
    if($this->session->userdata('flag')==2 ){
        echo "
            <div id='fail'>The login failed</div>
        ";
    }
    if(isset($success)){
        echo "
            <div id='success'>The user has been registered</div>
        ";
    }
?>

<div class="navbar">
  <ul class="navbar-item">
    <li style="background: white; border-bottom: solid #AAAAAA 1px; border-right: none; height: 49px;">
    	<img id='logo' src='<?=base_url()?>/assets/image/logo.png'>
    </li>
    <?php 
         if( $this->session->userdata('sign')==2) echo "
            <a href='".base_url()."CA'><li>Home</li></a>
            <a href='".base_url()."welcome'><li>Logout</li></a>";
        

         if( $this->session->userdata('sign')==1) echo "
            <a href='".base_url()."welcome'><li>Logout</li></a>";
        

    	if( $this->session->userdata('reg')==1) echo "
    	 	<a href='".base_url()."welcome'><li>Home</li></a>";
	?>
  </ul>
</div>