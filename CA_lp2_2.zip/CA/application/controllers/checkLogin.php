<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class CheckLogin extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function index(){
			$email = $this->input->post('email');
			$pass = $this->input->post('pass');
			$this->load->model("anggotaCertified");
			$cek='';
			$cek = $this->anggotaCertified->doCheck($email,$pass);

			$data['flag'] = 1;
			$data['title']='Home user';
			$data['email'] = $email;
			$data['sign'] = 1;

			if ($cek){
				$data['flag'] = 1;
				$this->session->set_userdata('id_akun',$cek->id_akun);
				$this->session->set_userdata('sign',$data['sign']);
				$this->session->set_userdata('nama',$cek->nama);
				$this->session->set_userdata('title',$data['title']);
				$this->session->set_userdata('flag',$data['flag']);

				if($cek->hak_akses==1){
					$data['sign']=2;
					$this->session->set_userdata('sign',$data['sign']);
					$this->session->set_userdata('hak_akses',$cek->hak_akses);
					$this->session->set_userdata('title','Home CA-admin');
					$this->load->view('template/head');
					$this->load->view('ca_home');
					$this->load->view('template/foot');	
					return;
				}
				else{
					
					$this->load->view('template/head');
					$this->load->view('login_success');
					$this->load->view('template/foot');	
				}
				
			}
			else {
				$data['flag'] = 2;
				$this->session->set_userdata('flag',$data['flag']);
				$this->load->view('template/head');
				$this->load->view('welcome_message');
				$this->load->view('template/foot');
			}
		}
		
		public function upload_it(){
			$config['upload_path'] = base_url().'/uploads/';
			$config['allowed_types'] = 'gif|jpg|png|txt';
			$config['max_size']	= '2000';

			$this->load->library('upload', $config);
			echo $this->input->post('cekcek'),"<br/>";
			$img = 'upl';
			if(!$this->upload->do_upload($img)){
				echo $this->upload->display_errors();
			}
			else{
				echo "Udah di upload dong";
			}
		}

	}

?>