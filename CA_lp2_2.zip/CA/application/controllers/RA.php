<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class RA extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function register(){
			$this->session->unset_userdata('reg');
			$inp['pass'] = $this->input->post('pass');
			$inp['pass'] = $this->input->post('pass');
			$inp['fullname'] = $this->input->post('fullname');
			$inp['email'] = $this->input->post('email');
			$this->load->model('register_model');
			$out=$this->register_model->index($inp);
			$data['success']=1;
			$this->load->view('template/head',$data);
			$this->load->view('welcome_message');
			$this->load->view('template/foot');
		}

		public function FormRegister(){
			$data['title'] = 'Register user';
			$this->session->set_userdata('title',$data['title']);
			$this->session->set_userdata('reg',1);
			$this->load->view('template/head');
			$this->load->view('register.php');
			$this->load->view('template/foot');
		}

		public function submitCSR(){
			$this->load->model('request');
			$new_id = $this->request->max_id();
			$userid = $this->session->userdata('id_akun');
			
			if (!is_dir('./requests/' . $userid)) {
				echo '../requests/' . $userid.'<br/>';
				echo "Creating ./requests/" . $userid.'<br/>';
				mkdir('./requests/' . $userid,0777,true);
			}
			$config['upload_path'] = './requests/' . $userid . '/';
			$config['allowed_types'] = '*';
			$config['file_name'] = $new_id;
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('csr')) {
				echo $this->upload->display_errors();
				return;
			}

			$this->request->insert($userid, './requests/' . $userid .	 '/' . $new_id);
			$this->load->view('template/head');
			$this->load->view('login_success');
			$this->load->view('template/foot');
		}
	}

?>