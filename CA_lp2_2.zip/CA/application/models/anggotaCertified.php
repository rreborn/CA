<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class AnggotaCertified extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function doCheck($email,$pass){
			#$data = $array('usn'=>$usn,'pass'=>$pass);
			$opt = ['salt' => $email];
			$this->db->select('id_akun,nama,hak_akses');
			$this->db->from('akun');
			$this->db->where('email',$email);
			$this->db->where('password',password_hash($pass, PASSWORD_BCRYPT, $opt));
			$query = $this->db->get();
			if($query->num_rows() > 0 )return $query->row();
			else return 0;
		}
	}

?>