<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Certificate extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function insert($userid, $common_name, $valid_from, $valid_until){
			$new_cert = [
					'id_akun' => $userid,
					'common_name' => $common_name,
					'valid_from' => $valid_from,
					'valid_until' => $valid_until
			];
			$this->db->insert('certificate', $new_cert);
		}

		public function update_cert_filename($serial, $cert_file) {
			$new_cert = [
				'cert_file' => $cert_file
			];
			$this->db->where('serial', $serial);
			$this->db->update('certificate', $new_cert);	
		}

		public function max_serial() {
			$this->db->select_max('serial');
			$query = $this->db->get('certificate');
			if ($query->num_rows > 0) {
				return $query->row()->serial;
			}
			else return 1;
		}

		public function get_all_certificate() {
			$query = $this->db->get('certificate');
			return $query->result();
		}

    public function get_user_certificate($id) {
      $this->db->where('id_akun', $id);
      $query = $this->db->get('certificate');
      return $query->result();
    }

	}

?>
