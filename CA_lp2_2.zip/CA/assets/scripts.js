	function change(data)
	{
		var inp=document.getElementById(data);
		if(inp.style.display=='none' || inp.style.display=='')inp.style.display = 'block';
		else inp.style.display='none';
	}

	function show_form() {
		var inp=document.getElementById('csr_div');
		if(inp.style.display=='none' || inp.style.display=='')inp.style.display = 'block';
		else inp.style.display='none';
	}
	
	function generate_command() {
	cn = document.getElementById('csr-cn').value;
	o = document.getElementById('csr-o').value;
	ou = document.getElementById('csr-ou').value;
	l = document.getElementById('csr-l').value;
	st = document.getElementById('csr-st').value;
	e = document.getElementById('csr-email').value;
	string = 'openssl req -new -newkey rsa:2048 -nodes -out "' + cn + '.csr" -keyout "' + cn + '.key" -subj "/C=ID' +
	          '/ST=' + st + '/L=' + l + '/O=' + o + '/OU=' + ou + '/emailAddress=' + e +'/CN=' + cn + '"';
	document.getElementById('output').innerHTML  = string;
	}