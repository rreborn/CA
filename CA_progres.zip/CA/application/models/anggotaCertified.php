<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class AnggotaCertified extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function doCheck($usn,$pass){
			#$data = $array('usn'=>$usn,'pass'=>$pass);
			$this->db->select('id');
			$this->db->from('anggotacertified');
			$this->db->where('usn',$usn);
			$this->db->where('pass',$pass);
			$query = $this->db->get();
			if($query->num_rows() > 0 )return 1;
			else return 0;
		}
	}

?>