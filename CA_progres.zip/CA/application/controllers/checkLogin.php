<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class CheckLogin extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function index(){
			$usn = $this->input->post('usn');
			$pass = $this->input->post('pass');
			echo "usn= ".$usn."<br>";
			echo "pass= ".$pass."<br>";
			$this->load->model("anggotaCertified");
			$cek = $this->anggotaCertified->doCheck($usn,$pass);

			$flag['flag'] = 0;
			if ($cek==1)$this->load->view('login_success');
			else $this->load->view('welcome_message',$flag);
		}
	}

?>