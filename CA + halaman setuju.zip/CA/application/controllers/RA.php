<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class RA extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function register(){
			$inp['pass'] = $this->input->post('pass');
			$inp['fullname'] = $this->input->post('fullname');
			$inp['email'] = $this->input->post('email');
			$this->load->model('register_model');
			$out=$this->register_model->index($inp);
			$data['title'] = 'our CA';
			$this->load->view('template/head',$data);
			$this->load->view('welcome_message.php');
			$this->load->view('template/foot');
			echo $out;
		}

		public function FormRegister(){
			$data['title'] = 'Register user';
			$this->load->view('template/head',$data);
			$this->load->view('register.php');
			$this->load->view('template/foot');
		}

		public function submitCSR(){
			$this->load->model('request');
			$new_id = $this->request->max_id();
			$userid = $this->session->userdata('id_akun');
			
			if (!is_dir('../requests/' . $userid)) {
				echo '../requests/' . $userid.'<br/>';
				echo "Creating ./requests/" . $userid.'<br/>';
				if(is_dir('./requests/'))echo "wowwowowowoow";
				mkdir('./requests/' . $userid,0777,true);
			}
			#var_dump(base_url().'requests/' . $userid);
			#echo '<br/>';
			#print_r($_FILES);
			$config['upload_path'] = '../requests/' . $userid . '/';
			$config['allowed_types'] = '*';
			$config['file_name'] = $new_id;
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('csr')) {
				echo $this->upload->display_errors();
				return;
			}

			$this->request->insert($userid, './requests/' . $userid .	 '/' . $new_id);
			$this->load->view('template/head',$data);
			$this->load->view('login_success',$data);
			$this->load->view('template/foot');
		}
	}

?>