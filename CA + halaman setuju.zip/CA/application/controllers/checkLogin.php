<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class CheckLogin extends CI_Controller{
		function __construct()
		{
			parent::__construct();
		}

		public function index(){
			$email = $this->input->post('email');
			$pass = $this->input->post('pass');
			$this->load->model("anggotaCertified");
			$cek='';
			$cek = $this->anggotaCertified->doCheck($email,$pass);

			$data['flag'] = 0;
			$data['title']='Home user';
			$data['email'] = $email;
			$data['sign'] = 1;

			if ($cek->id_akun!=''){
				$this->session->set_userdata('id_akun',$cek->id_akun);
				$this->session->set_userdata('nama',$cek->nama);
				$data['flag'] = 1;
				$this->load->view('template/head',$data);
				if($cek->hak_akses<=1)
					$this->load->view('login_success',$data);
				else if($cek->hak_akses==2)
					{
						$this->load->model("request");
						$dat['flag']=1;
						$dat['title']='Home CA';
						$dat['re']=$this->request->getAll();
						$dat['akun']=$this->anggotaCertified->getAll();
						$this->load->view('Request',$dat);
					}
				$this->load->view('template/foot');
			}
			else {
				$this->load->view('template/head',$data);
				$this->load->view('welcome_message');
				$this->load->view('template/foot');
			}
		}
		
		public function upload_it(){
			$config['upload_path'] = base_url().'/uploads/';
			$config['allowed_types'] = 'gif|jpg|png|txt';
			$config['max_size']	= '2000';

			$this->load->library('upload', $config);
			echo $this->input->post('cekcek'),"<br/>";
			$img = 'upl';
			if(!$this->upload->do_upload($img)){
				echo $this->upload->display_errors();
			}
			else{
				echo "Udah di upload dong";
			}
		}

	}

?>