<table border="1">
	<th>ID CSR</th>
	<th>Nama</th>
	<th>Tanggal request</th>
	<th>Operasi</th>
	<?php
		foreach($re as $row)
		  {
			echo "<tr>";
			echo "<td>" . $row->id_csr ."</td>";
			foreach($akun as $a)
			   {
				  if($row->id_akun==$a->id_akun)
					echo "<td>" . $a->nama ."</td>";
			   }
			echo "<td>" . $row->tanggal ."</td>";
			echo "<td>" . "Setujui" ."</td>";
			echo "</tr>";
		  }
	?>
</table>