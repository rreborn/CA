<h1 class="mid" style="margin-top: 50px; margin-bottom: 50px; font-size: 3em">Selamat Datang, <?php if(isset($email))echo $email; ?></h1>

<p>If you would like to edit this page you'll find it located at:</p>
<a href="<?=base_url()?>RA">download Certificate</a><br/>
<div class="mid"><a href="#" id="button" onclick="change('login')">Buat Sertifikat Baru</a></div><br>
<div id='login' >
	<form action="<?=base_url()?>RA/submitCSR" enctype="multipart/form-data" method="post">
		<input class="inp" type="file" name="csr"/>
		<input  id="sub" type="submit" value="login"/>
	</form>
</div>
<a href="<?=base_url()?>RA/getCertificate">get Certificate</a>
<p>If you are exploring CodeIgniter for the very first time, you should start by reading the <a href="user_guide/">User Guide</a>.</p>
