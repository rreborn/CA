<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Register_model extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function index($data){
			try{
				$option = ['salt'=>$data['email']];
				$cek = array(
					'password' => password_hash($data['pass'], PASSWORD_BCRYPT, $option),
					'nama' => $data['fullname'],
					'email' => $data['email']	);
				$this->db->insert('akun',$cek);
				return "Success";
			}
			catch(Exception $e){
				return $e;
			}
		}
	}

?>