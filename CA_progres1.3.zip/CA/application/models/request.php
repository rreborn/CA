<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Request extends CI_Model{
		function __construct()
		{
			parent::__construct();
		}

		public function insert($userid, $csr_file){
			$new_req = [
					'id_akun' => $userid,
					'tanggal' => (new DateTime())->format("Y-m-d H:i:s"),
					'csr_file' => $csr_file
			];

			$this->db->insert('request', $new_req);
		}

		public function max_id() {
			$this->db->select_max('id_csr');
			$query = $this->db->get('request');
			if ($query->num_rows > 0) {
				return $query->row()->id_csr + 1;
			}
			else return 1;
		}

		public function index() {
			$this->load->view('form_request.php');
		}

	}

?>
