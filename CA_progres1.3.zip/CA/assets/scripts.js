	function change(data)
	{
		var inp=document.getElementById(data);
		if(inp.style.display=='none' || inp.style.display=='')inp.style.display = 'block';
		else inp.style.display='none';
	}